exports.menu = (prefix) => {
    return `Hai Kak👋


*INFO MENU*
🍀 -stats
🍀 -limit
🍀 -balance
🍀 -runtime
🍀 -speed
🍀 -owner
🍀 -donasi
🍀 -sourcecode

*Sticker Menu*
🍀 -sticker
🍀 -swm
🍀 -take
🍀 -toimg
🍀 -attp *text*

*Other Menu*
🍀 -ytmp4 *url*
🍀 -ytmp3 *url*
🍀 -igdl *url*
🍀 -fbdl *url*
🍀 -tiktok *url*
🍀 -yts *query*
🍀 -play *query*
🍀 -playmp4 *query*
🍀 -igstalk *username*
🍀 -ghstalk *username*

*Text Marker*
🍀 -blackpink text
🍀 -tahta text
🍀 -neon text
🍀 -glitch text1|text2
🍀 -thundername text
🍀 -pornhub text1|text2

*Baileys*
🍀 -tagme
🍀 -kontak nomor|nama
🍀 -hidetag
🍀 -jadian
🍀 -ganteng
🍀 -cantik

*Premium*
🍀 -addprem @tag
🍀 -delprem @tag
🍀 -cekprem
🍀 -listprem

*Ban*
🍀 -ban @tag
🍀 -unban @tag
🍀 -listban

*Game*
🍀 -topbalance
🍀 -buylimit
🍀 -buyglimit
🍀 -tictactoe @tag
🍀 -tebakgambar
🍀 -family100

*VVIBU*
🍀 -waifu
🍀 -loli
🍀 -nekonime
🍀 -megumin
🍀 -sagiri
🍀 -shinobu

*Random*
🍀 -apakah
🍀 -bisakah
🍀 -kapankah
🍀 -hobby
🍀 -rate
🍀 -cekbapak
🍀 -seberapagay
🍀 -truth
🍀 -dare

*Group*
🍀 -afk
🍀 -infogrup
🍀 -chatinfo
🍀 -add 628xx
🍀 -kick @tag
🍀 -promote @tag
🍀 -demote @tag
🍀 -linkgc
🍀 -leave
🍀 -setdesc
🍀 -setgrupname
🍀 -setppgrup
🍀 -opengrup
🍀 -closegrup
🍀 -join
🍀 -tagall
🍀 -mute
🍀 -unmute

*Enable / Disable*
🍀 -antilink
🍀 -welcome
🍀 -left
🍀 -antibadword
🍀 -listbadword
🍀 -addbadword
🍀 -delbadword

*Owner*
🍀 -self
🍀 -public
🍀 -setpp
🍀 -setname
🍀 -setbio
🍀 -setprefix
🍀 -bc
🍀 -clearall
🍀 -exif nama|author`
}
